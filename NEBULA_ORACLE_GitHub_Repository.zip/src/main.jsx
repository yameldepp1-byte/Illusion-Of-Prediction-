import React, {useEffect, useMemo, useState} from "react";
import {createRoot} from "react-dom/client";
import {ref, push, onValue, off} from "firebase/database";
import {db} from "./firebase";
import {predict, evaluate} from "./engine";
import "./style.css";

const API=import.meta.env.VITE_API_BASE || "http://localhost:8787";

function App(){
  const [history,setHistory]=useState([]);
  const [online,setOnline]=useState(false);
  const [lastError,setLastError]=useState("");
  const [pred,setPred]=useState(null);
  const [audit,setAudit]=useState([]);
  const [now,setNow]=useState(Date.now());
  const [pending,setPending]=useState(null);

  useEffect(()=>{
    const load=async()=>{try{const r=await fetch(`${API}/api/history`);const j=await r.json();setHistory(j.list||[]);setOnline(true);setLastError(j.error||"")}catch(e){setOnline(false);setLastError(e.message)}};
    load();
    const ws=new WebSocket((API.replace(/^http/,"ws"))+"/ws");
    ws.onopen=()=>setOnline(true);
    ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==="history")setHistory(m.list||[]);if(m.type==="error")setLastError(m.message)};
    ws.onclose=()=>setOnline(false);
    const t=setInterval(()=>setNow(Date.now()),250);
    return ()=>{clearInterval(t);ws.close()};
  },[]);

  useEffect(()=>{
    if(!history.length) return;
    setPred(predict(history));
    // When the live feed advances, evaluate the prediction that was stored for that issue.
    if(pending && history[0]?.issue === pending.issue){
      const ev=evaluate(pending.pred, history[0]);
      const record={...pending,actual:history[0],eval:ev,evaluatedAt:Date.now()};
      setAudit(a=>[...a,record].slice(-100));
      if(db) push(ref(db,"oracle/audits"),record).catch(()=>{});
      setPending(null);
    }
    // Prepare a pending prediction for the next issue without pretending it is a result.
    try {
      const next=(BigInt(history[0].issue)+1n).toString();
      setPending({issue:next,pred:predict(history)});
    } catch {}
  },[history]);

  useEffect(()=>{
    if(!db)return;
    const r=ref(db,"oracle/audits");
    const unsub=onValue(r,s=>{const v=s.val()||{};setAudit(Object.values(v).slice(-100).reverse())});
    return ()=>off(r);
  },[]);

  const latest=history[0];
  const nextIssue=latest?.issue ? (()=>{try{return (BigInt(latest.issue)+1n).toString()}catch{return latest.issue}})() : "—";
  const secondsLeft=latest ? 60-new Date(now).getUTCSeconds() : 0;
  const metrics=useMemo(()=>{
    const rows=audit.filter(x=>x?.eval);
    const w=rows.filter(x=>x.eval.sizeWin).length;
    return {n:rows.length,w,rate:rows.length?Math.round(w/rows.length*100):0};
  },[audit]);

  async function savePrediction(){
    if(!db||!pred||!nextIssue)return;
    await push(ref(db,"oracle/audits"),{issue:nextIssue,pred,createdAt:Date.now(),type:"prediction"});
  }

  return <div className="shell">
    <header><div><div className="eyebrow">LIVE • WINGO ANALYTICS</div><h1>NEBULA ORACLE</h1></div>
      <div className={"status "+(online?"on":"off")}><i/> {online?"SERVER LIVE":"OFFLINE"}</div></header>
    <section className="hero">
      <div className="period"><span>NEXT PERIOD</span><b>{nextIssue}</b><em>00:{String(secondsLeft).padStart(2,"0")}</em></div>
      <div className="prediction">
        <div className="orb">{pred?.size||"WARMUP"}</div>
        <div className="grid">
          <div><small>NUMBER</small><strong>{pred?.number??"—"}</strong></div>
          <div><small>COLOUR</small><strong>{pred?.color??"—"}</strong></div>
          <div><small>MODEL SCORE</small><strong>{pred?pred.confidence+"%":"—"}</strong></div>
        </div>
        <p>{pred?.method||"Waiting for enough live history…"}</p>
        <button onClick={savePrediction} disabled={!db||!pred}>SAVE AUDIT TO FIREBASE</button>
      </div>
    </section>
    <section className="stats">
      <div><span>Observed</span><b>{history.length}</b></div>
      <div><span>Audited</span><b>{metrics.n}</b></div>
      <div><span>Size hit rate</span><b>{metrics.rate}%</b></div>
    </section>
    <section className="panel"><div className="panel-head"><h2>LIVE RESULT TAPE</h2><span>{history[0]?.issue||"—"}</span></div>
      <div className="tape">{history.slice(0,24).map(x=><div className="chip" key={x.issue}><b>{x.number}</b><span>{x.size}</span><small>{x.issue.slice(-5)}</small></div>)}</div>
    </section>
    <section className="panel"><div className="panel-head"><h2>MODEL SIGNALS</h2><span>TRANSPARENT</span></div>
      <ul>{(pred?.signals||["No signal yet"]).map((x,i)=><li key={i}>{x}</li>)}</ul>
      <div className="notice">Confidence is a statistical score, not a guarantee. The app records every prediction/result so the model can be backtested instead of displaying fabricated accuracy.</div>
      {lastError&&<div className="error">{lastError}</div>}
    </section>
    <footer>NEBULA ORACLE • server-proxied live feed • Firebase audit log</footer>
  </div>
}
createRoot(document.getElementById("root")).render(<App/>);